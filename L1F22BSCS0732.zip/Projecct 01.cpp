#include<iostream>
using namespace std;
int main()
{
int id,pass,userPass=123,errorcounter,num;
char room,Press,a;
int arr[10]={1,2,3,4,5,6,7,8,9,10},t_room=10,booked=2,available;
available=t_room-booked;

	cout<<"\t \t \t \t--------------------------------------"<<endl;
	cout<<"\t \t \t \tWelcome to the Hotel Management System"<<endl;
	cout<<"\t \t \t \t--------------------------------------"<<endl;
	
cout<<"Enter Your ID :";
cin>>id;

do{
cout<<"Enter Your Password :";
cin>>pass;	
if(pass!=userPass)
errorcounter++;	
}while(errorcounter>=1 && pass!=userPass);
	if(pass==userPass)
cout<<"\t \t \t \t You're login with employee id : "<<id<<endl;	
	else if(pass!=userPass)
cout<<"\t \t \t \tWrong Id or Password"<<endl;

cout<<"\nPress F to book room on First floor"<<endl;
cout<<"\nPress S to book room on Second floor"<<endl;
cout<<"\nPress T to book room on Third floor"<<endl;

cout<<"\n\t \t \t  Press the Key of the floor you want to book a room: ";
cin>>room;	 
     // First Floor
	
if(room=='F'|| room=='f')
{
	cout<<"The Information of rooms on First floor are as follows down below :\n";
	cout<<"\nRoom number "<<arr[3]<<" is already booked\n";
	cout<<"Room number "<<arr[9]<< " is already booked\n";
	cout<<"\n"<<available<<" Rooms are available\n";
	cout<<booked<<" rooms has already been booked\n";
	cout<<"\nPress B to book a room or Press E to exit: ";
cin>>Press;	
		if(Press == 'B' || Press=='b')
{
cout<<"Enter the number of rooms you want to book : ";
cin>>num;
		if(num<=available)
{
	cout<<"\n\t\t\t\t\tCongratulations!! Your room has been booked\n\n";
	cout<<"Now Available rooms in first floor are "<<available-num;
	cout<<"\nBooked room in first floor are "<<booked+num;
		cout<<"\n\n\t\t\t\t\tThankYou for Using Hotel Management System";

}	
else
	cout<<"Room limit exceeded";
}
else if(Press == 'E' || Press=='e')
	cout<<"\n\n\t\t\t\t\t    ThankYou for Using Hotel Management System";
}

// Second Floor

else if(room=='S'|| room=='s')
{
		cout<<"The Information of rooms on second floor are as follows down below :\n";
	cout<<"\nRoom number "<<arr[0]<<" is already booked\n";
	cout<<"Room number "<<arr[5]<< " is already booked\n";
	cout<<"\n"<<available<<" Rooms are available\n";
	cout<<"\n"<<booked<<" rooms has already been booked\n";{
	cout<<"\n Press B to book a room or Press E to exit : ";
cin>>Press;		
		if(Press == 'B' || Press=='b')
{
cout<<"Enter the number of rooms you want to book : ";
cin>>num;
		if(num<=available)
{
cout<<"\n\t\t\t\t\tCongratulations!! Your room has been booked\n\n";
cout<<"Now Available rooms in first floor are "<<available-num;
cout<<"\nBooked room in first floor are "<<booked+num;
cout<<"\n\n\t\t\t\t\t ThankYou for Using Hotel Management System";
}	
		else
cout<<"Room limit exceeded";
}
		else if(Press == 'E' || Press=='e')
cout<<"\n\n\t\t\t\t\tThankYou for Using Hotel Management System";

}
}

//thirddd floor

else if(room=='T' || room=='t')
{

  	cout<<"The Information of rooms on third floor are as follows down below :\n";
	cout<<"\nRoom number "<<arr[9]<<" is already booked\n";
	cout<<"Room number "<<arr[6]<< " is already booked\n";
	cout<<"\n"<<available<<" Rooms are available\n";
	cout<<"\n"<<booked<<" rooms has already been booked\n";
	cout<<"\n Press B to book a room or Press E to exit : ";
cin>>Press;		
if(Press == 'B' || Press=='b')
{
	cout<<"Enter the number of rooms you want to book : ";
cin>>num;
if(num<=available)
{
	cout<<"\n\t\t\t\t\tCongratulations!! Your room has been booked\n\n";
	cout<<"Now Available rooms in first floor are "<<available-num;
	cout<<"\nBooked room in first floor are "<<booked+num;
		cout<<"\n\n\t\t\t\t\t ThankYou for Using Hotel Management System";

}	
else
	cout<<"Room limit exceeded";
}
else if(Press == 'E' || Press=='e')
	cout<<"\n\n\t\t\t\t\t    ThankYou for Using Hotel Management System";
}

else
	cout<<"Wrong Input";

}

